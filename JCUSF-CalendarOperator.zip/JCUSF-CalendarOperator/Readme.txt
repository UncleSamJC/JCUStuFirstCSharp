IMPORTANT NOTE:

☆ You can use this software for free, and distribute/share it freely.
☆ This JCU StudentFirstOperator is provided as is without any guarantees or warranty. 
☆ The author takes no responsibility of the outcome of this software.
☆ NO Mac version. This application does not support Mac OS.
☆ Current version has only been tested only on Win10.
☆ For the course subject dictionary, you can add as much lines as you like, just keep the format. I use "|" to split the strings.

Dezhi 
Aug, 2020